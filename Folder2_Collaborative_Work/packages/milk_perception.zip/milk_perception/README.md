# milk_perception

Computer vision and perception processing package for the MILK robotics system.

## Overview

This package provides perception and vision processing capabilities for the MILK robot, including:
- Image processing pipelines
- Computer vision algorithms
- Sensor data preprocessing
- Perception filtering and fusion

## Dependencies

- `rclpy` - ROS2 Python client library
- `message_filters` - Synchronization of multiple message streams
- `depth_image_proc` - Depth image processing
- `image_proc` - Standard image processing
- `sensor_msgs` - Standard sensor message types
- `std_msgs` - Standard message types
- `python3-numpy` - Numerical computing

## Installation

```bash
cd ~/milk_dragon_ws
colcon build --packages-select milk_perception
source install/setup.bash
```

## Usage

### As a Component

This package is typically launched as part of the milk_bringup system:

```bash
ros2 launch milk_bringup bringup.launch.py
```

### Standalone (if applicable)

Check the package for available launch files:

```bash
ros2 pkg list | grep milk_perception
ros2 launch milk_perception [launch_file].launch.py
```

## Nodes

Check the source code and launch files for available nodes and their parameters.

## Topics

Published and subscribed topics depend on the specific vision processing nodes active.

## Configuration

Configuration files may be located in the `config/` directory.

## Troubleshooting

### Image Processing Issues
- Verify camera driver is running: `ros2 topic list | grep camera`
- Check image resolution and format match expectations
- Review depth_image_proc and image_proc parameters

### Performance Issues
- Monitor CPU usage: `ros2 topic hz /[topic_name]`
- Reduce image resolution if needed
- Check for synchronized subscriber bottlenecks

## References

- [ROS2 Image Processing](https://docs.ros.org/en/humble/Tutorials/Image-Processing.html)
- [depth_image_proc Documentation](https://github.com/ros-perception/image_common/tree/humble/depth_image_proc)
- [image_proc Documentation](https://github.com/ros-perception/image_common/tree/humble/image_proc)

## Future Enhancements

- [ ] Add specific perception pipeline documentation
- [ ] Add example launch files
- [ ] Add parameter documentation
- [ ] Integration with additional vision libraries

## Maintainer

Maintained by the MILK project team.
