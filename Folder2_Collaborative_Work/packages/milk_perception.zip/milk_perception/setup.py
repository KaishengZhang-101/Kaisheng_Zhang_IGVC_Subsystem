from setuptools import find_packages, setup
from glob import glob
import os

package_name = 'milk_perception'

setup(
  name=package_name, version='0.0.1',
  packages=find_packages(exclude=['test']),
  data_files=[
    ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
    ('share/' + package_name, ['package.xml']),
    (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
    (os.path.join('share', package_name, 'rviz'), glob('rviz/*.rviz')),
    (os.path.join('share', package_name, 'config'), glob('config/*.yaml')),
  ],
  install_requires=['setuptools'], zip_safe=True,
  entry_points={
    'console_scripts': [
        'scan_depth_fusion = milk_perception.scan_depth_fusion_node:main',
    ],
},

)

