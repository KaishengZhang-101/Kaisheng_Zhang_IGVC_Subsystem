find_package(PkgConfig REQUIRED)
pkg_check_modules(LIBFREENECT REQUIRED libfreenect)

find_path(libfreenect_INCLUDE_DIR
  NAMES libfreenect.h
  HINTS ${LIBFREENECT_INCLUDE_DIRS}
)

find_library(libfreenect_LIBRARY
  NAMES freenect
  HINTS ${LIBFREENECT_LIBRARY_DIRS}
)

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(libfreenect DEFAULT_MSG
  libfreenect_LIBRARY
  libfreenect_INCLUDE_DIR
)

set(libfreenect_LIBRARIES ${libfreenect_LIBRARY})
set(libfreenect_INCLUDE_DIRS ${libfreenect_INCLUDE_DIR})
