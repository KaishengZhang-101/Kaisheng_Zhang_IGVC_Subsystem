#!/usr/bin/env python3
"""
Direct Motor Controller - Bridges lane_follow_controller to p2os motor driver.
Ensures /cmd_vel commands reach the robot and publishes diagnostics.
"""

import math
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
from geometry_msgs.msg import Twist
from std_msgs.msg import String, Float32
import time


class MotorController(Node):
    """
    Direct motor control with safety checks and diagnostics.
    Subscribes to /cmd_vel and ensures it reaches the motor driver.
    """
    
    def __init__(self):
        super().__init__('motor_controller')
        
        self.declare_parameter('input_topic', '/cmd_vel')
        self.declare_parameter('output_topic', '/p2os_driver/cmd_vel')
        self.declare_parameter('motor_enable', True)
        self.declare_parameter('max_linear_vel', 0.5)
        self.declare_parameter('max_angular_vel', 1.0)
        
        self.input_topic = self.get_parameter('input_topic').value
        self.output_topic = self.get_parameter('output_topic').value
        self.motor_enable = bool(self.get_parameter('motor_enable').value)
        self.max_linear_vel = float(self.get_parameter('max_linear_vel').value)
        self.max_angular_vel = float(self.get_parameter('max_angular_vel').value)
        
        # QoS profile matching P2OS driver (BEST_EFFORT)
        qos_best_effort = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=10
        )
        
        qos_reliable = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            history=HistoryPolicy.KEEP_LAST,
            depth=10
        )
        
        # Subscription to incoming commands
        self.sub_cmd = self.create_subscription(
            Twist, self.input_topic, self.cmd_callback, qos_reliable
        )
        
        # Publication to motor driver (using BEST_EFFORT to match P2OS)
        self.pub_motor = self.create_publisher(
            Twist, self.output_topic, qos_best_effort
        )
        
        # Try also publish to standard /cmd_vel for compatibility
        self.pub_cmd_vel_compat = self.create_publisher(
            Twist, '/cmd_vel', qos_best_effort
        )
        
        # Diagnostics publishers
        self.pub_status = self.create_publisher(String, '/motor_status', qos_reliable)
        self.pub_linear_vel = self.create_publisher(Float32, '/motor_linear_vel', qos_reliable)
        self.pub_angular_vel = self.create_publisher(Float32, '/motor_angular_vel', qos_reliable)
        
        # State tracking
        self.last_cmd_time = None
        self.cmd_count = 0
        self.motor_active = False
        self.last_linear = 0.0
        self.last_angular = 0.0
        
        # Diagnostics timer
        self.diag_timer = self.create_timer(0.5, self.publish_diagnostics)
        
        self.get_logger().info(
            f'Motor Controller started ✅\n'
            f'  Input: {self.input_topic}\n'
            f'  Output: {self.output_topic}\n'
            f'  Max Linear: {self.max_linear_vel} m/s\n'
            f'  Max Angular: {self.max_angular_vel} rad/s\n'
            f'  Motor Enable: {self.motor_enable}'
        )
    
    def cmd_callback(self, msg: Twist):
        """Process incoming Twist command."""
        if not self.motor_enable:
            self.get_logger().warn('Motor disabled - ignoring command')
            return
        
        # Extract velocities
        linear_x = msg.linear.x
        angular_z = msg.angular.z
        
        # Safety clipping
        linear_x = max(-self.max_linear_vel, min(self.max_linear_vel, linear_x))
        angular_z = max(-self.max_angular_vel, min(self.max_angular_vel, angular_z))
        
        # Update state
        self.last_cmd_time = time.time()
        self.cmd_count += 1
        self.motor_active = (abs(linear_x) > 0.01 or abs(angular_z) > 0.01)
        self.last_linear = linear_x
        self.last_angular = angular_z
        
        # Create safe command
        cmd = Twist()
        cmd.linear.x = float(linear_x)
        cmd.linear.y = 0.0
        cmd.linear.z = 0.0
        cmd.angular.x = 0.0
        cmd.angular.y = 0.0
        cmd.angular.z = float(angular_z)
        
        # Publish to motor driver
        self.pub_motor.publish(cmd)
        self.pub_cmd_vel_compat.publish(cmd)
        
        # Log significant commands
        if abs(linear_x) > 0.01 or abs(angular_z) > 0.05:
            self.get_logger().debug(
                f'CMD #{self.cmd_count}: linear={linear_x:.3f} m/s, angular={angular_z:.3f} rad/s'
            )
    
    def publish_diagnostics(self):
        """Publish motor status diagnostics."""
        t_now = time.time()
        
        # Check if receiving commands
        if self.last_cmd_time is None:
            age_sec = None
            status_msg = "⚠️  Waiting for commands..."
        else:
            age_sec = t_now - self.last_cmd_time
            if age_sec > 1.0:
                status_msg = f"⚠️  No commands for {age_sec:.1f}s"
            elif self.motor_active:
                status_msg = f"✅ Active (cmd #{self.cmd_count})"
            else:
                status_msg = f"✅ Idle (cmd #{self.cmd_count})"
        
        # Publish status
        status = String()
        status.data = status_msg
        self.pub_status.publish(status)
        
        # Publish velocity values
        lin_msg = Float32(data=self.last_linear)
        ang_msg = Float32(data=self.last_angular)
        self.pub_linear_vel.publish(lin_msg)
        self.pub_angular_vel.publish(ang_msg)
        
        # Log periodically
        self.get_logger().info(status_msg)


def main():
    rclpy.init()
    node = MotorController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
