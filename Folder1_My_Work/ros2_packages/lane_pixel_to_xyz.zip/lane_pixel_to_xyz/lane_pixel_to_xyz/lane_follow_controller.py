#!/usr/bin/env python3
import math
import numpy as np

import rclpy
from rclpy.node import Node

from geometry_msgs.msg import PointStamped, Twist
from sensor_msgs.msg import LaserScan
from std_msgs.msg import Bool


class LaneFollowController(Node):
    def __init__(self):
        super().__init__('lane_follow_controller')

        # topics
        self.declare_parameter('lane_target_topic', '/lane_target_point')
        self.declare_parameter('lane_valid_topic', '/lane_valid')
        self.declare_parameter('scan_topic', '/scan')
        self.declare_parameter('cmd_vel_topic', '/cmd_vel')

        # control params
        self.declare_parameter('k_ang', 1.2)
        self.declare_parameter('max_angular_z', 0.6)

        self.declare_parameter('v_fast', 0.12)
        self.declare_parameter('v_slow', 0.06)
        self.declare_parameter('slow_distance', 1.2)
        self.declare_parameter('stop_distance', 0.7)

        # obstacle avoidance params
        self.declare_parameter('front_angle_deg', 20.0)
        self.declare_parameter('front_stop', 0.8)
        self.declare_parameter('front_avoid', 1.2)
        self.declare_parameter('side_clear', 1.0)
        self.declare_parameter('side_margin', 0.15)
        self.declare_parameter('avoid_turn', 0.35)

        # safety
        self.declare_parameter('lane_timeout_sec', 0.5)
        self.declare_parameter('scan_timeout_sec', 0.5)

        self.lane_target_topic = self.get_parameter('lane_target_topic').value
        self.lane_valid_topic = self.get_parameter('lane_valid_topic').value
        self.scan_topic = self.get_parameter('scan_topic').value
        self.cmd_vel_topic = self.get_parameter('cmd_vel_topic').value

        self.k_ang = float(self.get_parameter('k_ang').value)
        self.max_angular_z = float(self.get_parameter('max_angular_z').value)

        self.v_fast = float(self.get_parameter('v_fast').value)
        self.v_slow = float(self.get_parameter('v_slow').value)
        self.slow_distance = float(self.get_parameter('slow_distance').value)
        self.stop_distance = float(self.get_parameter('stop_distance').value)

        self.front_angle_deg = float(self.get_parameter('front_angle_deg').value)

        self.front_stop = float(self.get_parameter('front_stop').value)
        self.front_avoid = float(self.get_parameter('front_avoid').value)
        self.side_clear = float(self.get_parameter('side_clear').value)
        self.side_margin = float(self.get_parameter('side_margin').value)
        self.avoid_turn = float(self.get_parameter('avoid_turn').value)

        self.lane_timeout_sec = float(self.get_parameter('lane_timeout_sec').value)
        self.scan_timeout_sec = float(self.get_parameter('scan_timeout_sec').value)

        # latest states
        self.last_lane_target = None
        self.last_lane_time = None

        self.last_lane_valid = False
        self.last_valid_time = None

        self.last_scan = None
        self.last_scan_time = None

        # subs
        self.sub_lane_target = self.create_subscription(
            PointStamped, self.lane_target_topic, self.lane_target_cb, 10
        )
        self.sub_lane_valid = self.create_subscription(
            Bool, self.lane_valid_topic, self.lane_valid_cb, 10
        )
        self.sub_scan = self.create_subscription(
            LaserScan, self.scan_topic, self.scan_cb, 10
        )

        # pub
        self.pub_cmd = self.create_publisher(Twist, self.cmd_vel_topic, 10)

        # control loop
        self.timer = self.create_timer(0.1, self.timer_cb)  # 10 Hz

        self.get_logger().info(
            f'lane_follow_controller started ✅ '
            f'lane_target={self.lane_target_topic}, lane_valid={self.lane_valid_topic}, scan={self.scan_topic}'
        )

    def now_sec(self):
        return self.get_clock().now().nanoseconds * 1e-9

    def lane_target_cb(self, msg: PointStamped):
        self.last_lane_target = msg
        self.last_lane_time = self.now_sec()

    def lane_valid_cb(self, msg: Bool):
        self.last_lane_valid = bool(msg.data)
        self.last_valid_time = self.now_sec()

    def scan_cb(self, msg: LaserScan):
        self.last_scan = msg
        self.last_scan_time = self.now_sec()

    def get_sector_min_range(self, scan: LaserScan, angle_deg_min: float, angle_deg_max: float):
        if scan is None:
            return None

        ranges = np.array(scan.ranges, dtype=np.float32)
        n = len(ranges)
        if n == 0:
            return None

        angles = scan.angle_min + np.arange(n) * scan.angle_increment

        a0 = math.radians(angle_deg_min)
        a1 = math.radians(angle_deg_max)

        mask = (angles >= a0) & (angles <= a1)
        if not np.any(mask):
            return None

        sector = ranges[mask]
        valid = np.isfinite(sector) & (sector > scan.range_min) & (sector < scan.range_max)
        sector = sector[valid]

        if sector.size == 0:
            return None

        return float(np.min(sector))

    def stop_robot(self):
        cmd = Twist()
        self.pub_cmd.publish(cmd)

    def timer_cb(self):
        t_now = self.now_sec()

        # timeout protection
        if self.last_lane_time is None or (t_now - self.last_lane_time) > self.lane_timeout_sec:
            self.stop_robot()
            return

        if self.last_scan_time is None or (t_now - self.last_scan_time) > self.scan_timeout_sec:
            self.stop_robot()
            return

        if self.last_lane_target is None or self.last_scan is None:
            self.stop_robot()
            return

        # lane validity protection
        if not self.last_lane_valid:
            self.stop_robot()
            return

        # target point in base_link frame:
        # x = forward, y = left
        x = float(self.last_lane_target.point.x)
        y = float(self.last_lane_target.point.y)

        if x <= 1e-3:
            self.stop_robot()
            return

        # lane steering: positive y (target on left) -> positive angular.z
        theta = math.atan2(y, x)
        omega_lane = self.k_ang * theta

        # lidar sectors
        d_front = self.get_sector_min_range(self.last_scan, -12.0, 12.0)
        d_left = self.get_sector_min_range(self.last_scan, 10.0, 40.0)
        d_right = self.get_sector_min_range(self.last_scan, -40.0, -10.0)

        if d_front is None or d_left is None or d_right is None:
            self.stop_robot()
            return

        omega_avoid = 0.0
        linear_x = self.v_fast

        # reactive obstacle avoidance
        if d_front <= self.front_stop:
            # very close obstacle: try side escape first, else stop
            if d_left > d_right + self.side_margin and d_left > self.side_clear:
                linear_x = self.v_slow
                omega_avoid = +self.avoid_turn
            elif d_right > d_left + self.side_margin and d_right > self.side_clear:
                linear_x = self.v_slow
                omega_avoid = -self.avoid_turn
            else:
                linear_x = 0.0
                omega_lane = 0.0
                omega_avoid = 0.0

        elif d_front <= self.front_avoid:
            # obstacle ahead but not too close: bias away from obstacle
            linear_x = self.v_slow
            if d_left > d_right + self.side_margin and d_left > self.side_clear:
                omega_avoid = +self.avoid_turn
            elif d_right > d_left + self.side_margin and d_right > self.side_clear:
                omega_avoid = -self.avoid_turn
            else:
                omega_avoid = 0.0

        else:
            # normal lane following
            if d_front <= self.slow_distance:
                linear_x = self.v_slow
            else:
                linear_x = self.v_fast

        angular_z = omega_lane + omega_avoid

        # clamp angular speed
        angular_z = max(-self.max_angular_z, min(self.max_angular_z, angular_z))

        cmd = Twist()
        cmd.linear.x = float(linear_x)
        cmd.angular.z = float(angular_z)
        self.pub_cmd.publish(cmd)


def main():
    rclpy.init()
    node = LaneFollowController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
