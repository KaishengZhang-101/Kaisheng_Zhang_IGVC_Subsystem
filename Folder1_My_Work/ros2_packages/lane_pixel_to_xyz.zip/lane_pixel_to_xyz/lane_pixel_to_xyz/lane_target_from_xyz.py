#!/usr/bin/env python3
import numpy as np

import rclpy
from rclpy.node import Node

from sensor_msgs.msg import PointCloud2
from sensor_msgs_py import point_cloud2
from geometry_msgs.msg import PointStamped
from std_msgs.msg import Bool


class LaneTargetFromXyz(Node):
    def __init__(self):
        super().__init__('lane_target_from_xyz')

        # parameters
        self.declare_parameter('left_topic', '/lane_left_points_xyz')
        self.declare_parameter('right_topic', '/lane_right_points_xyz')
        self.declare_parameter('target_topic', '/lane_target_point')
        self.declare_parameter('valid_topic', '/lane_valid')
        self.declare_parameter('output_frame', 'base_link')

        self.declare_parameter('lookahead_x', 1.2)
        self.declare_parameter('window_half_width', 0.35)
        self.declare_parameter('min_points_per_side', 2)

        self.left_topic = self.get_parameter('left_topic').value
        self.right_topic = self.get_parameter('right_topic').value
        self.target_topic = self.get_parameter('target_topic').value
        self.valid_topic = self.get_parameter('valid_topic').value
        self.output_frame = str(self.get_parameter('output_frame').value)

        self.lookahead_x = float(self.get_parameter('lookahead_x').value)
        self.window_half_width = float(self.get_parameter('window_half_width').value)
        self.min_points_per_side = int(self.get_parameter('min_points_per_side').value)

        self.left_msg = None
        self.right_msg = None

        self.sub_left = self.create_subscription(
            PointCloud2, self.left_topic, self.left_cb, 10
        )
        self.sub_right = self.create_subscription(
            PointCloud2, self.right_topic, self.right_cb, 10
        )

        self.pub_target = self.create_publisher(PointStamped, self.target_topic, 10)
        self.pub_valid = self.create_publisher(Bool, self.valid_topic, 10)

        self.timer = self.create_timer(0.1, self.timer_cb)  # 10 Hz

        self.get_logger().info(
            f'lane_target_from_xyz started ✅ left={self.left_topic}, right={self.right_topic}, '
            f'output_frame={self.output_frame}'
        )

    def left_cb(self, msg: PointCloud2):
        self.left_msg = msg

    def right_cb(self, msg: PointCloud2):
        self.right_msg = msg

    def cloud_to_array(self, msg: PointCloud2):
        pts = []
        for p in point_cloud2.read_points(msg, field_names=('x', 'y', 'z'), skip_nans=True):
            pts.append([float(p[0]), float(p[1]), float(p[2])])

        if not pts:
            return np.empty((0, 3), dtype=np.float32)

        return np.array(pts, dtype=np.float32)

    def filter_window(self, pts: np.ndarray):
        if pts.shape[0] == 0:
            return pts

        xmin = self.lookahead_x - self.window_half_width
        xmax = self.lookahead_x + self.window_half_width

        # base_link convention: x = forward
        mask = (pts[:, 0] > xmin) & (pts[:, 0] < xmax)
        return pts[mask]

    def publish_valid(self, flag: bool):
        msg = Bool()
        msg.data = flag
        self.pub_valid.publish(msg)

    def timer_cb(self):
        if self.left_msg is None or self.right_msg is None:
            self.publish_valid(False)
            return

        left_pts = self.cloud_to_array(self.left_msg)
        right_pts = self.cloud_to_array(self.right_msg)

        left_win = self.filter_window(left_pts)
        right_win = self.filter_window(right_pts)

        if left_win.shape[0] < self.min_points_per_side or right_win.shape[0] < self.min_points_per_side:
            self.publish_valid(False)
            return

        left_mean = np.mean(left_win, axis=0)
        right_mean = np.mean(right_win, axis=0)
        target = 0.5 * (left_mean + right_mean)

        out = PointStamped()
        out.header.stamp = self.get_clock().now().to_msg()
        out.header.frame_id = self.left_msg.header.frame_id if self.left_msg.header.frame_id else self.output_frame
        out.point.x = float(target[0])
        out.point.y = float(target[1])
        out.point.z = float(target[2])
        self.pub_target.publish(out)

        self.publish_valid(True)


def main():
    rclpy.init()
    node = LaneTargetFromXyz()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
