#!/usr/bin/env python3
"""
Lane visualization for RViz / SLAM overlay.

The incoming lane clouds / target are assumed to already be in base_link (or
another robot/world frame). No extra camera->robot conversion is done here.
"""

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Point, PointStamped
from sensor_msgs.msg import PointCloud2
from sensor_msgs_py import point_cloud2
from std_msgs.msg import ColorRGBA
from visualization_msgs.msg import Marker, MarkerArray


class LaneVisualizerSlam(Node):
    def __init__(self):
        super().__init__('lane_visualizer')

        self.declare_parameter('left_topic', '/lane_left_points_xyz')
        self.declare_parameter('right_topic', '/lane_right_points_xyz')
        self.declare_parameter('target_topic', '/lane_target_point')
        self.declare_parameter('marker_topic', '/lane_visualization')
        self.declare_parameter('line_width', 0.03)
        self.declare_parameter('point_size', 0.05)
        self.declare_parameter('target_size', 0.10)
        self.declare_parameter('lifetime_sec', 0.25)

        left_topic = self.get_parameter('left_topic').value
        right_topic = self.get_parameter('right_topic').value
        target_topic = self.get_parameter('target_topic').value
        marker_topic = self.get_parameter('marker_topic').value

        self.line_width = float(self.get_parameter('line_width').value)
        self.point_size = float(self.get_parameter('point_size').value)
        self.target_size = float(self.get_parameter('target_size').value)
        self.lifetime_sec = float(self.get_parameter('lifetime_sec').value)

        self.left_msg = None
        self.right_msg = None
        self.target_msg = None

        self.pub = self.create_publisher(MarkerArray, marker_topic, 10)
        self.create_subscription(PointCloud2, left_topic, self.on_left, 10)
        self.create_subscription(PointCloud2, right_topic, self.on_right, 10)
        self.create_subscription(PointStamped, target_topic, self.on_target, 10)

        self.timer = self.create_timer(0.1, self.publish_markers)
        self.get_logger().info(
            f'lane_visualizer started: left={left_topic}, right={right_topic}, target={target_topic}, out={marker_topic}'
        )

    def on_left(self, msg: PointCloud2):
        self.left_msg = msg

    def on_right(self, msg: PointCloud2):
        self.right_msg = msg

    def on_target(self, msg: PointStamped):
        self.target_msg = msg

    def cloud_to_points(self, msg: PointCloud2):
        pts = []
        for x, y, z in point_cloud2.read_points(msg, field_names=('x', 'y', 'z'), skip_nans=True):
            p = Point()
            p.x = float(x)
            p.y = float(y)
            p.z = float(z)
            pts.append(p)

        pts.sort(key=lambda p: p.x)
        return pts

    def make_marker(self, header, ns, mid, mtype, rgba, sx, sy=None, sz=None):
        m = Marker()
        m.header = header
        m.ns = ns
        m.id = mid
        m.type = mtype
        m.action = Marker.ADD
        m.pose.orientation.w = 1.0
        m.scale.x = sx
        m.scale.y = sx if sy is None else sy
        m.scale.z = sx if sz is None else sz
        m.color = rgba
        m.frame_locked = True
        m.lifetime.sec = int(self.lifetime_sec)
        m.lifetime.nanosec = int((self.lifetime_sec - int(self.lifetime_sec)) * 1e9)
        return m

    def publish_markers(self):
        markers = MarkerArray()
        mid = 0

        if self.left_msg is not None:
            left_pts = self.cloud_to_points(self.left_msg)
            if left_pts:
                m_pts = self.make_marker(
                    self.left_msg.header, 'left_lane_pts', mid, Marker.POINTS,
                    ColorRGBA(r=0.0, g=1.0, b=1.0, a=0.9),
                    self.point_size, self.point_size, self.point_size,
                )
                mid += 1
                m_pts.points = left_pts
                markers.markers.append(m_pts)

                if len(left_pts) >= 2:
                    m_line = self.make_marker(
                        self.left_msg.header, 'left_lane_line', mid, Marker.LINE_STRIP,
                        ColorRGBA(r=0.0, g=1.0, b=1.0, a=0.9),
                        self.line_width, 0.0, 0.0,
                    )
                    mid += 1
                    m_line.points = left_pts
                    markers.markers.append(m_line)

        if self.right_msg is not None:
            right_pts = self.cloud_to_points(self.right_msg)
            if right_pts:
                m_pts = self.make_marker(
                    self.right_msg.header, 'right_lane_pts', mid, Marker.POINTS,
                    ColorRGBA(r=1.0, g=0.0, b=1.0, a=0.9),
                    self.point_size, self.point_size, self.point_size,
                )
                mid += 1
                m_pts.points = right_pts
                markers.markers.append(m_pts)

                if len(right_pts) >= 2:
                    m_line = self.make_marker(
                        self.right_msg.header, 'right_lane_line', mid, Marker.LINE_STRIP,
                        ColorRGBA(r=1.0, g=0.0, b=1.0, a=0.9),
                        self.line_width, 0.0, 0.0,
                    )
                    mid += 1
                    m_line.points = right_pts
                    markers.markers.append(m_line)

        if self.target_msg is not None:
            tp = Point()
            tp.x = float(self.target_msg.point.x)
            tp.y = float(self.target_msg.point.y)
            tp.z = float(self.target_msg.point.z)

            m_target = self.make_marker(
                self.target_msg.header, 'lane_target', mid, Marker.SPHERE,
                ColorRGBA(r=1.0, g=0.1, b=0.1, a=0.95),
                self.target_size, self.target_size, self.target_size,
            )
            mid += 1
            m_target.pose.position = tp
            markers.markers.append(m_target)

            m_ray = self.make_marker(
                self.target_msg.header, 'target_ray', mid, Marker.LINE_STRIP,
                ColorRGBA(r=1.0, g=1.0, b=0.0, a=0.8),
                max(0.5 * self.line_width, 0.01), 0.0, 0.0,
            )
            mid += 1
            origin = Point()
            origin.x = 0.0
            origin.y = 0.0
            origin.z = 0.0
            m_ray.points = [origin, tp]
            markers.markers.append(m_ray)

        if markers.markers:
            self.pub.publish(markers)


def main(args=None):
    rclpy.init(args=args)
    node = LaneVisualizerSlam()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
