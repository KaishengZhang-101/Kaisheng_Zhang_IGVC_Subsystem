#!/usr/bin/env python3
import math
import numpy as np

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy

from sensor_msgs.msg import Image, CameraInfo, PointCloud2
from sensor_msgs_py import point_cloud2
from geometry_msgs.msg import PointStamped
from std_msgs.msg import Float32MultiArray, Header


class PixelToXyzNode(Node):
    """
    Convert lane pixels to 3D lane points by intersecting each camera ray with the
    ground plane instead of trusting per-pixel depth.

    Output convention:
      frame_id = base_link (configurable)
      x = forward
      y = left
      z = up ~= 0 on the ground plane

    Geometry model:
      1) pixel (u,v) -> normalized camera ray [xn, yn, 1]
      2) convert to base_link-style direction [1, -xn, -yn]
      3) apply downward camera pitch around base_link +Y
      4) intersect with ground plane z = ground_z
    """

    def __init__(self):
        super().__init__('pixel_to_xyz')

        # fallback intrinsics (will be overwritten by /camera_info)
        self.fx = 587.0460716
        self.fy = 587.0460716
        self.cx = 317.39001517
        self.cy = 234.3008072

        # output frame and camera mounting parameters in base_link
        self.declare_parameter('output_frame', 'base_link')
        self.declare_parameter('camera_x', 0.199)
        self.declare_parameter('camera_y', 0.0)
        self.declare_parameter('camera_z', 0.726)
        self.declare_parameter('pitch_deg', 0.0)
        self.declare_parameter('ground_z', 0.0)
        self.declare_parameter('max_range', 2.0)

        self.output_frame = str(self.get_parameter('output_frame').value)
        self.camera_x = float(self.get_parameter('camera_x').value)
        self.camera_y = float(self.get_parameter('camera_y').value)
        self.camera_z = float(self.get_parameter('camera_z').value)
        self.pitch_deg = float(self.get_parameter('pitch_deg').value)
        self.ground_z = float(self.get_parameter('ground_z').value)
        self.max_range = float(self.get_parameter('max_range').value)

        self.info_frame_id = 'kinect_depth'
        self.depth_img = None  # kept only for compatibility / debugging

        qos = QoSProfile(
            history=HistoryPolicy.KEEP_LAST,
            depth=1,
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.VOLATILE
        )

        # camera info is required; depth image subscription is kept for compatibility
        self.sub_depth = self.create_subscription(Image, '/depth/image_raw', self.depth_cb, qos)
        self.sub_info = self.create_subscription(CameraInfo, '/camera_info', self.info_cb, qos)

        # old topics kept for compatibility
        self.sub_uv_pt = self.create_subscription(PointStamped, '/lane_pixel_uv', self.uv_point_cb, 10)
        self.sub_uv_arr = self.create_subscription(Float32MultiArray, '/lane_pixels_uv', self.uv_array_cb, 10)

        # new left/right topics
        self.sub_uv_left = self.create_subscription(
            Float32MultiArray, '/lane_left_pixels_uv', self.uv_left_cb, 10
        )
        self.sub_uv_right = self.create_subscription(
            Float32MultiArray, '/lane_right_pixels_uv', self.uv_right_cb, 10
        )

        # old publishers kept
        self.pub_xyz_pt = self.create_publisher(PointStamped, '/lane_point_xyz', 10)
        self.pub_xyz_cloud = self.create_publisher(PointCloud2, '/lane_points_xyz', 10)

        # new left/right cloud publishers
        self.pub_xyz_left_cloud = self.create_publisher(PointCloud2, '/lane_left_points_xyz', 10)
        self.pub_xyz_right_cloud = self.create_publisher(PointCloud2, '/lane_right_points_xyz', 10)

        self.get_logger().info(
            'pixel_to_xyz started ✅ using ground-plane projection '
            f'(frame={self.output_frame}, cam=({self.camera_x:.3f}, {self.camera_y:.3f}, {self.camera_z:.3f}), '
            f'pitch_deg={self.pitch_deg:.2f}, ground_z={self.ground_z:.3f}, max_range={self.max_range:.1f}m)'
        )

    def info_cb(self, msg: CameraInfo):
        # K = [fx 0 cx; 0 fy cy; 0 0 1]
        self.fx = float(msg.k[0])
        self.fy = float(msg.k[4])
        self.cx = float(msg.k[2])
        self.cy = float(msg.k[5])
        if msg.header.frame_id:
            self.info_frame_id = msg.header.frame_id

    def depth_cb(self, msg: Image):
        # Not used for projection anymore; kept only so the existing launch remap remains valid.
        if msg.encoding != '16UC1':
            return

        try:
            h, w = msg.height, msg.width
            self.depth_img = np.frombuffer(msg.data, dtype='<u2').reshape((h, w))
        except Exception:
            self.depth_img = None

    def uv_to_ground(self, u: float, v: float):
        # pixel -> normalized camera ray
        xn = (u - self.cx) / self.fx
        yn = (v - self.cy) / self.fy

        # base_link-style direction before pitch:
        # camera optical axis -> +x (forward), right -> -y, down -> -z
        d = np.array([1.0, -xn, -yn], dtype=np.float64)

        # positive pitch_deg means camera looks downward
        pitch = math.radians(self.pitch_deg)
        cp = math.cos(pitch)
        sp = math.sin(pitch)
        r_pitch = np.array([
            [cp, 0.0, sp],
            [0.0, 1.0, 0.0],
            [-sp, 0.0, cp],
        ], dtype=np.float64)
        d = r_pitch @ d

        t = np.array([self.camera_x, self.camera_y, self.camera_z], dtype=np.float64)
        dz = float(d[2])
        if abs(dz) < 1e-9:
            return None

        s = (self.ground_z - t[2]) / dz
        if s <= 0.0:
            return None

        p = t + s * d
        p[2] = self.ground_z

        # 距离过滤：丢弃超过 max_range 的点
        if p[0] > self.max_range or p[0] < 0.0:
            return None

        return (float(p[0]), float(p[1]), float(p[2]))

    def uv_array_to_xyz_points(self, data):
        if len(data) < 2 or (len(data) % 2) != 0:
            self.get_logger().warn('lane pixel array must be [u0,v0,u1,v1,...] (even length)')
            return []

        pts = []
        for i in range(0, len(data), 2):
            u = float(data[i])
            v = float(data[i + 1])
            xyz = self.uv_to_ground(u, v)
            if xyz is not None:
                pts.append(xyz)
        return pts

    def publish_cloud(self, pts, publisher):
        if not pts:
            return

        header = Header()
        header.stamp = self.get_clock().now().to_msg()
        header.frame_id = self.output_frame

        cloud = point_cloud2.create_cloud_xyz32(header, pts)
        publisher.publish(cloud)

    def uv_point_cb(self, msg: PointStamped):
        u = float(msg.point.x)
        v = float(msg.point.y)

        xyz = self.uv_to_ground(u, v)
        if xyz is None:
            return

        out = PointStamped()
        out.header.stamp = self.get_clock().now().to_msg()
        out.header.frame_id = self.output_frame
        out.point.x, out.point.y, out.point.z = xyz
        self.pub_xyz_pt.publish(out)

    def uv_array_cb(self, msg: Float32MultiArray):
        pts = self.uv_array_to_xyz_points(msg.data)
        self.publish_cloud(pts, self.pub_xyz_cloud)

    def uv_left_cb(self, msg: Float32MultiArray):
        pts = self.uv_array_to_xyz_points(msg.data)
        self.publish_cloud(pts, self.pub_xyz_left_cloud)

    def uv_right_cb(self, msg: Float32MultiArray):
        pts = self.uv_array_to_xyz_points(msg.data)
        self.publish_cloud(pts, self.pub_xyz_right_cloud)


def main():
    rclpy.init()
    node = PixelToXyzNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
