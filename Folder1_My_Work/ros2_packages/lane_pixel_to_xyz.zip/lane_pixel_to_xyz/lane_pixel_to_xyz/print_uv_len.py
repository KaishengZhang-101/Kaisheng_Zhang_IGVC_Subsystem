#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray

class Dump(Node):
    def __init__(self):
        super().__init__('dump_uv_len')
        self.create_subscription(Float32MultiArray, '/lane_pixels_uv', self.cb, 10)
        print("waiting /lane_pixels_uv ...")

    def cb(self, msg: Float32MultiArray):
        n = len(msg.data) // 2
        print(f"lane_pixels_uv: floats={len(msg.data)}  points={n}")
        raise SystemExit

def main():
    rclpy.init()
    rclpy.spin(Dump())

if __name__ == '__main__':
    main()
