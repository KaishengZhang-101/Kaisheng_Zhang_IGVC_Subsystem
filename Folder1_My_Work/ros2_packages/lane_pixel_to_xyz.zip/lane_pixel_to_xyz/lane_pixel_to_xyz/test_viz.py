#!/usr/bin/env python3
"""
Test visualization with dummy lane data
用模拟数据测试可视化
"""

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PointStamped, Point
import time
import math


class DummyLanePublisher(Node):
    def __init__(self):
        super().__init__('dummy_lane_pub')
        
        # Publishers for visualization test
        self.pub_left = self.create_publisher(PointStamped, '/lane_left_xyz', 10)
        self.pub_right = self.create_publisher(PointStamped, '/lane_right_xyz', 10)
        self.pub_target = self.create_publisher(PointStamped, '/lane_target_point', 10)
        
        # Timer to publish data
        self.timer = self.create_timer(0.1, self.timer_callback)
        self.counter = 0
        
        self.get_logger().info('🎨 Dummy lane publisher started - publishing test data')
    
    def timer_callback(self):
        """Publish dummy lane data for testing visualization."""
        self.counter += 1
        
        # Simulate moving lane
        offset = math.sin(self.counter * 0.05) * 0.3
        
        # Left lane point
        left = PointStamped()
        left.header.frame_id = 'camera_depth_optical_frame'
        left.header.stamp = self.get_clock().now().to_msg()
        left.point.x = -0.15 + offset
        left.point.y = 0.0
        left.point.z = 1.0
        self.pub_left.publish(left)
        
        # Right lane point
        right = PointStamped()
        right.header.frame_id = 'camera_depth_optical_frame'
        right.header.stamp = self.get_clock().now().to_msg()
        right.point.x = 0.15 + offset
        right.point.y = 0.0
        right.point.z = 1.0
        self.pub_right.publish(right)
        
        # Target point (center)
        target = PointStamped()
        target.header.frame_id = 'camera_depth_optical_frame'
        target.header.stamp = self.get_clock().now().to_msg()
        target.point.x = offset
        target.point.y = 0.0
        target.point.z = 1.0
        self.pub_target.publish(target)
        
        if self.counter % 10 == 0:
            self.get_logger().info(f'Published {self.counter // 10}0 messages ✓')


def main():
    rclpy.init()
    node = DummyLanePublisher()
    rclpy.spin(node)
    rclpy.shutdown()


if __name__ == '__main__':
    main()
