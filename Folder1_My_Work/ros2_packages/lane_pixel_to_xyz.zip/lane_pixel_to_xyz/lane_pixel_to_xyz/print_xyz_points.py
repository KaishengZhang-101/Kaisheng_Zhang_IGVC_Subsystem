#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy

from sensor_msgs.msg import PointCloud2
from sensor_msgs_py import point_cloud2


class PrintXyzPoints(Node):
    def __init__(self):
        super().__init__('print_xyz_points')

        self.declare_parameter('topic', '/lane_points_xyz')
        self.declare_parameter('print_hz', 1.0)        # 每秒打印几次
        self.declare_parameter('max_points', -1)       # -1=打印全部点；否则只打印前 N 个
        self.declare_parameter('once', False)          # True=打印一帧就退出

        self.topic = self.get_parameter('topic').value
        self.print_hz = float(self.get_parameter('print_hz').value)
        self.max_points = int(self.get_parameter('max_points').value)
        self.once = bool(self.get_parameter('once').value)

        qos = QoSProfile(
            history=HistoryPolicy.KEEP_LAST,
            depth=1,
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE
        )

        self.last_msg = None
        self.sub = self.create_subscription(PointCloud2, self.topic, self.cb, qos)

        self.timer = self.create_timer(1.0 / max(self.print_hz, 0.1), self.on_timer)
        self.get_logger().info(
            f"print_xyz_points started ✅ topic={self.topic}, print_hz={self.print_hz}, "
            f"max_points={self.max_points}, once={self.once}"
        )

    def cb(self, msg: PointCloud2):
        self.last_msg = msg

    def on_timer(self):
        if self.last_msg is None:
            self.get_logger().info("waiting pointcloud ...")
            return

        msg = self.last_msg
        self.last_msg = None  # 防止重复打印同一帧（你也可以注释掉让它一直打印最新帧）

        pts = list(point_cloud2.read_points(
            msg, field_names=('x', 'y', 'z'), skip_nans=True
        ))

        n = len(pts)
        frame = msg.header.frame_id if msg.header.frame_id else '(empty)'
        print(f"\nframe_id={frame}  points={n}")

        if self.max_points > 0:
            pts = pts[:self.max_points]

        for i, (x, y, z) in enumerate(pts):
            print(f"{i:03d}: x={x: .4f}  y={y: .4f}  z={z: .4f}")

        if self.once:
            raise SystemExit


def main():
    rclpy.init()
    node = PrintXyzPoints()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
