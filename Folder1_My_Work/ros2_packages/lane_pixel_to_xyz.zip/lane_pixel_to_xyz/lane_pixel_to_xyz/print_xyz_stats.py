#!/usr/bin/env python3
import math
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy

from sensor_msgs.msg import PointCloud2
from sensor_msgs_py import point_cloud2


class PrintXyzStats(Node):
    def __init__(self):
        super().__init__('print_xyz_stats')

        self.declare_parameter('topic', '/lane_points_xyz')
        self.declare_parameter('print_hz', 1.0)

        self.topic = self.get_parameter('topic').value
        self.print_hz = float(self.get_parameter('print_hz').value)

        # BEST_EFFORT 更“通吃”（RELIABLE pub / BEST_EFFORT pub 都能接）
        qos = QoSProfile(
            history=HistoryPolicy.KEEP_LAST,
            depth=5,
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE
        )

        self.sub = self.create_subscription(PointCloud2, self.topic, self.cb, qos)

        self.last_stats = None
        self.last_stamp = None

        self.timer = self.create_timer(1.0 / max(self.print_hz, 0.1), self.on_timer)

        self.get_logger().info(f"print_xyz_stats started ✅ topic={self.topic}, print_hz={self.print_hz}")

    def cb(self, msg: PointCloud2):
        n = 0
        sum_r = 0.0
        sum_z = 0.0
        r_min = None

        # 读 x,y,z。skip_nans=True 会跳过 NaN 点
        for (x, y, z) in point_cloud2.read_points(msg, field_names=('x', 'y', 'z'), skip_nans=True):
            # 有些点可能是 0 或异常；这里你也可以加条件过滤
            r = math.sqrt(x*x + y*y + z*z)
            if r_min is None or r < r_min:
                r_min = r
            sum_r += r
            sum_z += z
            n += 1

        now = self.get_clock().now()
        self.last_stamp = now

        if n == 0:
            self.last_stats = {
                'n': 0,
                'r_min': None,
                'r_mean': None,
                'z_mean': None,
                'frame': msg.header.frame_id if msg.header.frame_id else '(empty)'
            }
            return

        self.last_stats = {
            'n': n,
            'r_min': float(r_min),
            'r_mean': float(sum_r / n),
            'z_mean': float(sum_z / n),
            'frame': msg.header.frame_id if msg.header.frame_id else '(empty)'
        }

    def on_timer(self):
        if self.last_stats is None:
            self.get_logger().info("waiting pointcloud ...")
            return

        age = None
        if self.last_stamp is not None:
            age = (self.get_clock().now() - self.last_stamp).nanoseconds / 1e9

        s = self.last_stats
        if s['n'] == 0:
            self.get_logger().info(f"n=0 frame={s['frame']} age={age:.3f}s")
            return

        self.get_logger().info(
            f"n={s['n']}  r_min={s['r_min']:.3f}m  r_mean={s['r_mean']:.3f}m  "
            f"z_mean={s['z_mean']:.3f}m  frame={s['frame']}  age={age:.3f}s"
        )


def main():
    rclpy.init()
    node = PrintXyzStats()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
