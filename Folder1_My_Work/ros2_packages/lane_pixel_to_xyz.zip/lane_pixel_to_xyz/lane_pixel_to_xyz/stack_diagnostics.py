#!/usr/bin/env python3
"""
Lane Following Stack Diagnostics - Monitors all components and connections.
"""

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PointStamped, Twist
from sensor_msgs.msg import LaserScan, PointCloud2
from std_msgs.msg import Bool
import time


class StackDiagnostics(Node):
    """Monitor all lane following and motor control components."""
    
    def __init__(self):
        super().__init__('stack_diagnostics')
        
        self.declare_parameter('check_interval', 2.0)  # seconds
        self.check_interval = float(self.get_parameter('check_interval').value)
        
        # Track messages
        self.messages = {
            'lane_target': {'received': False, 'time': None, 'count': 0},
            'lane_valid': {'received': False, 'time': None, 'count': 0},
            'lidar': {'received': False, 'time': None, 'count': 0},
            'cmd_vel': {'received': False, 'time': None, 'count': 0},
            'lane_left_xyz': {'received': False, 'time': None, 'count': 0},
            'lane_right_xyz': {'received': False, 'time': None, 'count': 0},
        }
        
        # Subscriptions
        self.create_subscription(PointStamped, '/lane_target_point', self.on_lane_target, 10)
        self.create_subscription(Bool, '/lane_valid', self.on_lane_valid, 10)
        self.create_subscription(LaserScan, '/scan', self.on_lidar, 10)
        self.create_subscription(Twist, '/cmd_vel', self.on_cmd_vel, 10)
        self.create_subscription(PointCloud2, '/lane_left_points_xyz', self.on_lane_left_xyz, 10)
        self.create_subscription(PointCloud2, '/lane_right_points_xyz', self.on_lane_right_xyz, 10)
        
        # Diagnostic timer
        self.timer = self.create_timer(self.check_interval, self.check_health)
        
        self.get_logger().info('Stack Diagnostics started ✅')
    
    def on_lane_target(self, msg: PointStamped):
        m = self.messages['lane_target']
        m['received'] = True
        m['count'] += 1
        m['time'] = self.get_clock().now()
    
    def on_lane_valid(self, msg: Bool):
        m = self.messages['lane_valid']
        m['received'] = True
        m['count'] += 1
        m['time'] = self.get_clock().now()
    
    def on_lidar(self, msg: LaserScan):
        m = self.messages['lidar']
        m['received'] = True
        m['count'] += 1
        m['time'] = self.get_clock().now()
    
    def on_cmd_vel(self, msg: Twist):
        m = self.messages['cmd_vel']
        m['received'] = True
        m['count'] += 1
        m['time'] = self.get_clock().now()
        vel = (msg.linear.x ** 2 + msg.angular.z ** 2) ** 0.5
        self.get_logger().debug(f'cmd_vel: linear={msg.linear.x:.3f}, angular={msg.angular.z:.3f}, norm={vel:.3f}')
    
    def on_lane_left_xyz(self, msg: PointCloud2):
        m = self.messages['lane_left_xyz']
        m['received'] = True
        m['count'] += 1
        m['time'] = self.get_clock().now()
    
    def on_lane_right_xyz(self, msg: PointCloud2):
        m = self.messages['lane_right_xyz']
        m['received'] = True
        m['count'] += 1
        m['time'] = self.get_clock().now()
    
    def check_health(self):
        """Print diagnostics."""
        t_now = self.get_clock().now()
        
        print("\n" + "="*70)
        print("LANE FOLLOWING STACK DIAGNOSTICS")
        print("="*70)
        
        all_ok = True
        for topic, info in self.messages.items():
            if info['received']:
                age = (t_now - info['time']).nanoseconds / 1e9
                status = "✅" if age < 1.0 else f"⚠️  ({age:.1f}s ago)"
                print(f"  {topic:20s}: {status:30s} count={info['count']}")
            else:
                print(f"  {topic:20s}: ❌ Not received")
                all_ok = False
        
        print("-"*70)
        if all_ok:
            print("✅ All topics active!")
        else:
            print("❌ Some topics missing - check roslaunch and connections")
        print("="*70 + "\n")


def main():
    rclpy.init()
    node = StackDiagnostics()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
