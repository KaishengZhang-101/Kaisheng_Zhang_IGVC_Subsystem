from setuptools import find_packages, setup
from glob import glob
import os

package_name = 'lane_pixel_to_xyz'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='ch1',
    maintainer_email='ch1@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
    'console_scripts': [
        'pixel_to_xyz = lane_pixel_to_xyz.pixel_to_xyz_node:main',
        'lane_target_from_xyz = lane_pixel_to_xyz.lane_target_from_xyz:main',
        'dummy_lane_pub = lane_pixel_to_xyz.dummy_lane_pub:main',
        'print_uv_len = lane_pixel_to_xyz.print_uv_len:main',
        'print_xyz_stats = lane_pixel_to_xyz.print_xyz_stats:main',
        'print_xyz_points = lane_pixel_to_xyz.print_xyz_points:main',
        'lane_follow_controller = lane_pixel_to_xyz.lane_follow_controller:main',
        'motor_controller = lane_pixel_to_xyz.motor_controller:main',
        'stack_diagnostics = lane_pixel_to_xyz.stack_diagnostics:main',
        'lane_visualizer = lane_pixel_to_xyz.lane_visualizer:main',
        'test_viz = lane_pixel_to_xyz.test_viz:main',
	],
     },
)
